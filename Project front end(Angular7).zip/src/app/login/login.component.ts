import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { DbServiceService } from '../db-service.service';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(private route:Router,private service:DbServiceService) { }

  ngOnInit() {
  }



  public value=true;
  validateUser(username:string,password:string)
  {
    
    this.service.validateUser(username,password).subscribe( data=> {
      
      if( data.responsevalue == true)
      {
        this.route.navigate(["/home"]);
      }
      else
      {
        this.value=false;
      }
    });
  
  }
  
}
