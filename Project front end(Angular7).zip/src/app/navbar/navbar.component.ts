import { Component, OnInit } from '@angular/core';
import { DbServiceService } from '../db-service.service';
import { Router } from '@angular/router';
import { getTypeNameForDebugging } from '@angular/common/src/directives/ng_for_of';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent implements OnInit {

  public name="";

  constructor(private service:DbServiceService,private route:Router) { }

  public flag=false;
  public flag1:Boolean=true;
  public users=[];

  ngOnInit() { 
    // this.service.getName().subscribe(
    //   data =>{
    //     console.log(data);
    //     this.name=data.name;
    //     console.log(this.name);
    //   }
    // );
  }

  reloadPage(){
    window.location.reload();
  }
  getUsers(){
    this.service.getUsers().subscribe(
      data=>{
        this.users =data;
      }
    );
    this.flag=true;
  }

  logoutsession(){

    this.service.logoutsession().subscribe(
      data=>{
        console.log(data.value)

        if(data.value=="true"){

          this.route.navigate(["/login"]);
        }

      });
   }

   deleteUsers(homeusername){
     this.service.deleteUsers(homeusername).subscribe(
       data=>{

         this.flag1=data.responsevalue;
         this.getUsers();
       }

     );


   }
 }
