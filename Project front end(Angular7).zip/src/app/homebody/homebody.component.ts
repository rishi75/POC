import { Component, OnInit } from '@angular/core';
import { DbServiceService } from '../db-service.service';
declare var jsPDF:any;
declare var alasql:any;
@Component({
  selector: 'app-homebody',
  templateUrl: './homebody.component.html',
  styleUrls: ['./homebody.component.css']
})
export class HomebodyComponent implements OnInit {

  constructor(private service:DbServiceService) {

   }

  ngOnInit() {
    
    this.service.getBrands().then(
      data =>{
        this.data1=data; 
       });
  }
  public flag=false;
  addBrands(brand_name,desktop_users,mobile_users,laptop_users){
    var total_users=desktop_users+mobile_users+laptop_users;
    this.service.addBrands(brand_name,desktop_users,mobile_users,laptop_users,total_users).subscribe(
      data=>{
        if(data.responsevalue == false){
          // this.service.addColor();
          window.location.reload();
        }
        else{
          this.flag=true;
        }
      }
    );
  };

  public data1=[];

  getExcel(){
     const opts=[{sheetid:"BrandReviews",header:true}];
     alasql('SELECT INTO XLSX("BrandReviews.xlsx",?) FROM ?', [opts, [this.data1]]);
  }

  getPdf(){
    var pdf=new jsPDF();
    var cols=[];
    var rows=[];
    for(var key in this.data1[0]){
      cols.push(key)
      }
    this.data1.forEach(element => {
              var temp=[]
              cols.forEach(value=>{
              temp.push(element[value])})
              rows.push(temp);
          });
    pdf.autoTable({head:[cols],body:rows});
    pdf.save("Brandreviews.pdf");
  }

}
