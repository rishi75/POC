export interface validateValue {
    responsevalue:Boolean
}
export interface LogoutResponse{
    value:string
}
export interface Name{
    name:string
}
export interface user{
    name:string;
    email:string;
    username:string;
    password:string;
}
export interface BrandReviews{
    brandName:string;
    desktopUsers:number;
    mobileUsers:number;
    laptopUsers:number;
    totalUsers:number

}