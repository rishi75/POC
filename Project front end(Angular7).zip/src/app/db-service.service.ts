import { Injectable } from '@angular/core';
import {HttpClient, HttpParams} from '@angular/common/http'
import { Observable, from } from 'rxjs';
import {validateValue, user} from './json'
import {LogoutResponse} from './json'
import {Name} from './json'
import {BrandReviews} from './json'
@Injectable({
  providedIn: 'root'
})
export class DbServiceService {

  constructor(private http:HttpClient) { }
     public user={"name":"","email":"","username":"","password":""};
     public brands={};
   
    validateUser(username:string,password:string):Observable<validateValue>{
      
      const params =new  HttpParams().set('username',username).set('password',password);
      return this.http.request<validateValue>("GET" ,"http://localhost:9090/getvalue", {responseType:"json",params} );
    };

    addDetails(signupname:string,signupemail:string,signupusername:string,signuppassword:string):Observable<validateValue>{
      this.user={"name":signupname,"email":signupemail,"username":signupusername,"password":signuppassword };
      return this.http.request<validateValue>("POST","http://localhost:9090/data",{body:this.user,responseType:"json"});
      };

    // getName():Observable<Name>{
    //    return this.http.request<Name>("GET","http://localhost:9090/getName",{responseType:"json"});
    // };

    logoutsession():Observable<LogoutResponse>{
      return this.http.request<LogoutResponse>("GET","http://localhost:9090/logout",{responseType:"json"});
      
    };
    getUsers():Observable<user[]>{
      return this.http.request<user[]>("GET", "http://localhost:9090/getusers",{responseType:"json"});
    }

    deleteUsers(homeusername:string):Observable<validateValue>{
      const params =new  HttpParams().set('homeusername',homeusername);
      return this.http.request<validateValue>("GET","http://localhost:9090/deleteusers",{responseType:"json",params});
    }
    
    // getBrands():Observable<BrandReviews[]>{
    //   return this.http.request<BrandReviews[]>("GET","http://localhost:9090/getBrandReviews",{responseType:"json"})
    // }

    addBrands(brand_name:string,desktop_users:number,mobile_users:number,laptop_users:number,total_users:number):Observable<validateValue>{
      this.brands={"brandName":brand_name,"desktopUsers":desktop_users,"mobileUsers":mobile_users,"laptopUsers":laptop_users,"totalUsers":total_users};
      return this.http.request<validateValue>("POST","http://localhost:9090/addBrands",{body:this.brands,responseType:"json"});
    }
    getBrands():Promise<BrandReviews[]>{
      return this.http.get<BrandReviews[]>("http://localhost:9090/getBrandReviews").toPromise();
    }

}
