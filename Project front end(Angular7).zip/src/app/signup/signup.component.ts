import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { DbServiceService } from '../db-service.service';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {

  constructor(private route:Router,private service:DbServiceService) { }

  ngOnInit() {
  
  }
  
  public constraint=false;
  addDetails(signupname:string,signupemail:string,signupusername:string,signuppassword:string){

    this.service.addDetails(signupname,signupemail,signupusername,signuppassword).subscribe(

      
       (data)=>{
  
        if( data.responsevalue != true)
        {
          this.route.navigate(["/login"]);
        }
        else
        {
          this.constraint=true;
        }
       }

    );


  }

}
