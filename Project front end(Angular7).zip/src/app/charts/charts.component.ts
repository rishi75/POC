import { Component, OnInit,ViewChild } from '@angular/core';
import { DbServiceService } from '../db-service.service';
import {Chart} from 'chart.js';
import {AgGridNg2} from 'ag-grid-angular'
import { config } from 'rxjs';
 
@Component({
  selector: 'app-charts',
  templateUrl: './charts.component.html',
  styleUrls: ['./charts.component.css']
})
export class ChartsComponent implements OnInit {
  
constructor(private service:DbServiceService) { }

@ViewChild('agGrid') agGrid: AgGridNg2;

  lineChart=[];
  pieChart=[];
  doughnutChart=[];
  barChart=[];
  public labels=[];
  public data1=[];
  public colors=['rgb(153,255,153)','rgb(51,255,255)','rgb(102,178,255)','rgb(255,153,155)','rgb(255,125,0)','rgb(255,125,255)','rgb(100,125,255)','rgb(255,125,100)'];
  private gridApi;
  private gridColumnApi;
  columnDefs = [
    {headerName: 'BrandName', field: 'brandName',sortable:true,checkboxSelection:true},
    {headerName: 'DesktopUsers', field: 'desktopUsers',sortable:true},
    {headerName: 'MobileUsers', field: 'mobileUsers',sortable:true},
    {headerName: 'LaptopUsers', field: 'laptopUsers',sortable:true},
    {headerName: 'TotalUsers', field: 'totalUsers',sortable:true},
];
rowData=[];
  ngOnInit() {

    this.service.getBrands().then(
      data =>{
             
   data.forEach(element => {
      this.labels.push(element["brandName"]);
      });
           
    data.forEach(element => {
        this.data1.push(element["totalUsers"]);
       });
       this.rowData=data
      });
   
  
  console.log(this.labels);
       this.charts(this.data1,this.labels);
  }

  public charts(line_data,line_labels):void{
    this.lineChart= new Chart('lineChart', {
      type: 'line',
      data: {
          labels:line_labels,
          datasets: [{
              label: "My First dataset",
              backgroundColor: 'rgb(255, 255, 255)',
              borderColor: 'rgb(255, 99, 132)',
              data: line_data,
          }]
      },
      options: {}
     });
     this.pieChart= new Chart('pieChart', {
      type: 'pie',
      data: {
          labels:line_labels,
          datasets: [{
              data: line_data,
              backgroundColor:this.colors,
          }]
      },
      options:{}
     });

     this.doughnutChart=new Chart('doughnutChart',{
       type:'doughnut',
       data:{
         labels:line_labels,
         datasets:[{
           data:line_data,
           backgroundColor:this.colors ,
         }]
       },

     options:{}
     });

     this.barChart= new Chart('barChart', {
      type: 'bar',
      data: {
          labels:line_labels,
          datasets: [{
              label: "My First dataset",
              backgroundColor: 'rgb(165, 255, 165)',
              data: line_data,
          }]
      },
      options: {}
     });

  }
   
   onGridReady(params) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
  }
  private array;
  onSelectionChanged(){
   this.array=this.gridApi.getSelectedRows();
   this.data1=[];
   this.labels=[];
   this.labels=["desktopUsers","mobileUsers","laptopUsers"];
   this.array.forEach(element => {
     this.data1.push(element["desktopUsers"]);
     this.data1.push(element["mobileUsers"]);
     this.data1.push(element["laptopUsers"]);
   });
    this.charts(this.data1,this.labels);
  }



}
  
