myApp.factory("servicefactory",function($http,$q){
var users=[]
var user={}
var factory={}
var uri="http://localhost:9090"
factory.addDetails=function(signupname,signupemail,signupusername,signuppassword)
{
var deferred = $q.defer()
user={name:signupname,email:signupemail,username:signupusername,password:signuppassword}
$http.post(uri+"/data",user).then(function(response) {
deferred.resolve(response.data)
});
return deferred.promise
};


factory.validUser=function(login_uname,login_password)
{
var deferred = $q.defer()
$http({url:uri+"/getvalue/",method:"GET",params:{username:login_uname,password:login_password}}).then(function(response){
deferred.resolve(response.data)
});
return deferred.promise
};

factory.getName=function()
{
var deferred = $q.defer()
$http.get(uri+"/getName").then(function(response){
deferred.resolve(response.data)
});
return deferred.promise
};


factory.logoutsession=function()
{
var deferred = $q.defer()
$http.get(uri+"/logout").then(function(response){
deferred.resolve(response.data)
});
return deferred.promise
};



factory.getUsers=function()
{
var deferred=$q.defer()
$http.get(uri+"/getusers").then(function(response){
deferred.resolve(response.data)
})
return deferred.promise
};

factory.deleteUsers=function(homeusername){
console.log(homeusername)
var deferred=$q.defer()
$http({url:uri+"/deleteusers/",method:"GET",params:{homeusername:homeusername}}).then(function(response){
deferred.resolve(response.data)
})
return deferred.promise
};

factory.addBrands=function(brand_name,desktop_users,mobile_users,laptop_users){
var deferred=$q.defer()
var totalUsers=desktop_users+mobile_users+laptop_users
var brands={brandName:brand_name,desktopUsers:desktop_users,mobileUsers:mobile_users,laptopUsers:laptop_users,totalUsers:totalUsers}
$http.post(uri+"/addBrands",brands).then(
function(response)
{deferred.resolve(response)})
return deferred.promise
};


factory.getBrandReviews=function(){
var deferred=$q.defer()
$http.get(uri+"/getBrandReviews").then(
function(response)
{
deferred.resolve(response)
}
)
return deferred.promise
};

return factory
});
