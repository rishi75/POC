myApp.controller("chartscontroller",function($scope,servicefactory){
$scope.brands=[]
$scope.data=[]
$scope.colors=['#ED402A', '#F0AB05', '#A0B421']
$scope.series=['Total Users']
servicefactory.getBrandReviews().then(
function(d)
{
d.data.forEach(element=>{
$scope.brands.push(element.brandName)
$scope.data.push(element.totalUsers)
})
}
)

})