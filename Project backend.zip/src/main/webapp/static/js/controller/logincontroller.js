myApp.controller("logincontroller",function($scope,servicefactory,$location){
$scope.value=true
$scope.validUser=function()
{
servicefactory.validUser($scope.username,$scope.password).then(
function(d){
$scope.value=d.responsevalue
if(d.responsevalue == true)
{
$location.path('/home')
}
});
};
});