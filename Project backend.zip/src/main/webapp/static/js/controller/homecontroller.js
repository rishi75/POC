myApp.controller("homecontroller",function($scope,servicefactory,$location,$route){

$scope.flag=false
$scope.show=false
$scope.flag1=true
$scope.users=[]

servicefactory.getName().then(
function(d){
$scope.name=d.name
});

$scope.logoutsession=function(){
servicefactory.logoutsession().then(
function(d){
if(d.value == 'true' )
{
$location.path('/')
}
});
};


$scope.getUsers=function(){

if($scope.name!=null)
{
servicefactory.getUsers().then(
function(d)
{
$scope.users=d
$scope.flag=true
});
}
};

$scope.reloadPage=function(){
$route.reload();
};

$scope.deleteUsers=function(){
if($scope.name!=null)
{
servicefactory.deleteUsers($scope.homeusername).then(
function(d)
{
$scope.flag1=d.responsevalue
$scope.getUsers()
});
}
};

$scope.addBrands=function(){

servicefactory.addBrands($scope.brand_name,$scope.desktop_users,$scope.mobile_users,$scope.laptop_users).then(
function(d)
{
console.log("addedBrands")
}
);
};

$scope.getPdf=function(){

servicefactory.getBrandReviews().then(
function(d)
{
var doc=new jsPDF()
var cols=[]
for(var key in d.data[0]){
cols.push(key)
}
var rows=[]

d.data.forEach(element => {
        var temp=[]
        cols.forEach(value=>{
        temp.push(element[value])})
        rows.push(temp);
    });


console.log(cols)
console.log(rows)
doc.autoTable({head:[cols],body:rows});
doc.save('Test.pdf');

console.log("pdf generated")
}
);
};

$scope.getExcel=function(){

servicefactory.getBrandReviews().then(
function(d)
{
console.log(d.data)
var opts = { sheetid: "BrandReviews", header: true }
alasql('SELECT * INTO XLSX(" BRAND_REVIEWS.xlsx ",?) FROM ?',[opts,d.data])
console.log("excel generated")
}
);
};

});