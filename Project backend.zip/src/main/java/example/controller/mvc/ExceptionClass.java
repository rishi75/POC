package example.controller.mvc;

import example.model.mvc.Response;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;


@ControllerAdvice
public class ExceptionClass {
    @ExceptionHandler(value = {DataIntegrityViolationException.class})
    public ResponseEntity<Response> exceptionHandler(Exception e){
        Response response=new Response();
        if(e instanceof DataIntegrityViolationException) {
            response.setResponsevalue(true);
            System.out.println("exception:" + e);
        }
        return new ResponseEntity<Response>(response, HttpStatus.OK);
    }
}
