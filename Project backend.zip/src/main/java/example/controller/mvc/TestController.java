package example.controller.mvc;

import example.model.mvc.*;
import example.services.ServiceClass;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpSession;
import java.util.List;

@CrossOrigin(origins = {"http://localhost:4200"})
@Controller
public class TestController{
    @Autowired
    private ServiceClass serviceClass;


    @RequestMapping(value = "/test")
    public String test() {
        return "/WEB-INF/index.jsp";
    }

    @RequestMapping(value = "/data",method= RequestMethod.POST)
    public ResponseEntity<Response> data(@RequestBody UserDetails user) {
        serviceClass.insert(user);
        Response response=new Response();
        response.setResponsevalue(false);
        return new ResponseEntity<Response>(response,HttpStatus.CREATED);
    }
    @RequestMapping(value = "/getvalue",method = RequestMethod.GET,produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Response> getData(@RequestParam("username") String uname, @RequestParam("password") String password,HttpSession httpSession){

        Response value= serviceClass.getName(uname,password);
        if(value.getResponsevalue()==true)
        {
            System.out.println("hi"+uname);
            httpSession.setAttribute("username",uname);

        }
        return new ResponseEntity<Response>(value,HttpStatus.OK);
    }

    @RequestMapping(value = "/getName",method = RequestMethod.GET)
    public ResponseEntity<Name> getName(HttpSession httpSession)
    {
        System.out.println(httpSession.getAttribute("username"));
       Name name= serviceClass.getUname(httpSession);
       return new ResponseEntity<Name>(name,HttpStatus.OK);
    }

    @RequestMapping(value = "/logout",method = RequestMethod.GET)
    public ResponseEntity<LogoutResponse> logout(HttpSession httpSession)
    {
        httpSession.removeAttribute("username");
        httpSession.invalidate();
        LogoutResponse logoutResponse=new LogoutResponse();
        logoutResponse.setValue("true");
        return new ResponseEntity<LogoutResponse>(logoutResponse,HttpStatus.OK);
    }
    @RequestMapping(value="/getusers",method = RequestMethod.GET)
    public ResponseEntity<List<UserDetails>> getUsers()
    {
        List<UserDetails> userDetailsList=serviceClass.getUsers();
        return new ResponseEntity<List<UserDetails>>(userDetailsList,HttpStatus.OK);
    }
    @RequestMapping(value="/deleteusers",method = RequestMethod.GET)
    public ResponseEntity<Response> deleteUsers(@RequestParam("homeusername") String username)
    {
        System.out.println(username);
        Response response=new Response();
        Boolean value=serviceClass.deleteUsers(username);
        response.setResponsevalue(value);
        return new ResponseEntity<Response>(response, HttpStatus.OK);
    }
    @RequestMapping(value = "/addBrands",method = RequestMethod.POST)
    public ResponseEntity<Response> addBrands(@RequestBody BrandsReviews brandsReviews)
    {
        serviceClass.insertBrands(brandsReviews);
        Response response=new Response();
        response.setResponsevalue(false);
        System.out.println("added");
        return new ResponseEntity<Response>(response,HttpStatus.OK);
    }

    @RequestMapping(value = "/getBrandReviews",method = RequestMethod.GET)
    public  ResponseEntity<List<BrandsReviews>> getBrandReviews()
    {
        List<BrandsReviews> brandsReviewsList=serviceClass.getBrandList();
        return new ResponseEntity<List<BrandsReviews>>(brandsReviewsList,HttpStatus.OK);
    }
}
