package example.services;

import example.model.mvc.BrandsReviews;
import example.model.mvc.Name;
import example.model.mvc.Response;
import example.model.mvc.UserDetails;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.servlet.http.HttpSession;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

@Repository
@Transactional
public class ServiceClass {
    @Autowired
    private HibernateTemplate hibernateTemplate;

    public void insert(UserDetails user)
    {
        hibernateTemplate.save(user);
    }
    public Response getName(String uname, String password)
    {
        UserDetails user=new UserDetails();
        Response response=new Response();
        if((user=hibernateTemplate.get(UserDetails.class,uname))==null)
        {
            response.setResponsevalue(false);
        }
        else {
            if(user.getUsername().equals(uname) && user.getPassword().equals(password))
            {
                response.setResponsevalue(true);
            }
            else
            {
                response.setResponsevalue(false);
            }

        }
        return response;
    }
    public Name getUname(HttpSession httpSession)
    {
        Name name=new Name();
        System.out.println(httpSession.getAttribute("username"));
        name.setName((String) httpSession.getAttribute("username"));
        return name;
    }

    public List<UserDetails> getUsers()
    {
        List<UserDetails> userDetailsList=new ArrayList<>();
        userDetailsList= (List<UserDetails>) hibernateTemplate.find("from UserDetails");
        return userDetailsList;
    }

    public Boolean deleteUsers(String username)
    {
        System.out.println(username);
        UserDetails user=new UserDetails();
        if((user=hibernateTemplate.get(UserDetails.class,username))==null)
            return false;
        hibernateTemplate.delete(user);
        return true;
    }
    public void insertBrands(BrandsReviews brandsReviews)
    {
        hibernateTemplate.save(brandsReviews);
    }

    public List<BrandsReviews> getBrandList()
    {
        List<BrandsReviews> brandsReviewsList=new ArrayList<>();
        brandsReviewsList= (List<BrandsReviews>) hibernateTemplate.find("from Brand_Reviews");
        return brandsReviewsList;
    }

}
