package example.model.mvc;

public class Response {
    private Boolean responsevalue;

    public Boolean getResponsevalue() {
        return responsevalue;
    }

    public void setResponsevalue(Boolean responsevalue) {
        this.responsevalue = responsevalue;
    }
}
