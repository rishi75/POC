package example.model.mvc;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import java.io.Serializable;
@Entity(name = "Brand_Reviews")
public class BrandsReviews implements Serializable{
    @Id
    private String brandName;
    private int desktopUsers;
    private int mobileUsers;
    private int laptopUsers;
    @Column(columnDefinition = "int default 0")
    private int totalUsers;

    public int getTotalUsers() {
        return totalUsers;
    }

    public void setTotalUsers(int totalUsers) {
        this.totalUsers = totalUsers;
    }



    public String getBrandName() {
        return brandName;
    }

    public void setBrandName(String brandName) {
        this.brandName = brandName;
    }

    public int getDesktopUsers() {
        return desktopUsers;
    }

    public void setDesktopUsers(int desktopUsers) {
        this.desktopUsers = desktopUsers;
    }

    public int getMobileUsers() {
        return mobileUsers;
    }

    public void setMobileUsers(int mobileUsers) {
        this.mobileUsers = mobileUsers;
    }

    public int getLaptopUsers() {
        return laptopUsers;
    }

    public void setLaptopUsers(int laptopUsers) {
        this.laptopUsers = laptopUsers;
    }
}
